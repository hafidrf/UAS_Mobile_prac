package com.hafidrf.uas_mobile_e_;

public class InArtikel {
    private String title;
    private String sneak;
    private String author;

    public InArtikel(String title, String sneak, String author) {
        this.title = title;
        this.sneak = sneak;
        this.author = author;

    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSneak() {
        return sneak;
    }

    public void setSneak(String sneak) {
        this.sneak = sneak;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }
}
