package com.hafidrf.uas_mobile_e_;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class ArtikelActivity extends AppCompatActivity {

    private String TAG = MainActivity.class.getSimpleName();
    private ListView lv;
    Spinner kategoriSpinner;
    Button btn_logout;

    ArrayList<HashMap<String, String>> lists;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_artikel);

        lists = new ArrayList<>();
        lv = (ListView) findViewById(R.id.list);
        lv.setOnItemClickListener(listClick);
        kategoriSpinner = (Spinner) findViewById(R.id.spinnerKategori);


        btn_logout = findViewById(R.id.btn_logout);
        btn_logout.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub


                Intent intent = new Intent(ArtikelActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });

    }

    private AdapterView.OnItemClickListener listClick = new AdapterView.OnItemClickListener () {

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            String value = lv.getItemAtPosition(position).toString();
            value = value.replace("{", "").replace("}", "");

            String[] temp = value.split(",");

            String idkategori = null, judul = null, idartikel = null, content = null, status = null;

            for (int i = 0; i < temp.length; i++) {
                if (temp[i].contains("idkategori=")) {
                    idkategori = temp[i].replace("idkategori=", "");
                }

                if (temp[i].contains("judul=")) {
                    judul = temp[i].replace("judul=", "");
                }

                if (temp[i].contains("idartikel=")) {
                    idartikel = temp[i].replace("idartikel=", "");
                }

                if (temp[i].contains("content=")) {
                    content = temp[i].replace("content=", "");
                }

                if (temp[i].contains("status=")) {
                    status = temp[i].replace("status=", "");
                }

            }

//            Intent goDetail = new Intent(ArtikelActivity.this, DetailActivity.class);
//            goDetail.putExtra("judul", judul);
//            goDetail.putExtra("kategori", idkategori);
//            goDetail.putExtra("content", content);
//            startActivity(goDetail);

                Intent goDetail = new Intent(ArtikelActivity.this, DetailActivity.class);
                goDetail.putExtra("idartikel", idartikel);
                startActivity(goDetail);
        }
    };

    public void proses(View v) {
        lists.clear();
        String kategori = String.valueOf(kategoriSpinner.getSelectedItem().toString());
        new GetLists(this).execute(kategori);
    }

    private class GetLists extends AsyncTask<String, Void, String> {

        private Context context;

        public GetLists(Context context) {
            this.context = context;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... s) {
            String idKat = s[0];
            int idKate;
            System.out.println(idKat+"->");
            //String coba = String.valueOf(kategoriSpinner.getSelectedItem().toString());
            if (idKat.equalsIgnoreCase("berita utama")){
                idKate = 1;
            } else {
                idKate = 2;
            }
            HttpControl sh = new HttpControl();
            // Making a request to url and getting response
            //String url = "http://192.168.1.14/prak_mobile/list.php?idkategori=" + idKat;
            String url = "http://hafidrf.com/uas/list.php?idkategori=" + idKate;
            System.out.println(url);
            String jsonStr = sh.makeServiceCall(url);

            Log.e(TAG, "Response from url: " + jsonStr);
            if (jsonStr != null) {
                try {
                    JSONObject jsonObj = new JSONObject(jsonStr);

                    // Getting JSON Array node
                    JSONArray contacts = jsonObj.getJSONArray("result");

                    // looping through All Contacts
                    for (int i = 0; i < contacts.length(); i++) {
                        JSONObject c = contacts.getJSONObject(i);
                        String idartikel = c.getString("idartikel");
                        String idkategori = c.getString("idkategori");
                        String judul = c.getString("judul");
                        String content = c.getString("content");
                        String status = c.getString("status");

                        // tmp hash map for single contact
                        HashMap<String, String> tempArtikel = new HashMap<>();

                        // adding each child node to HashMap key => value
                        tempArtikel.put("idartikel", idartikel);
                        tempArtikel.put("idkategori", idkategori);
                        tempArtikel.put("judul", judul);
                        tempArtikel.put("content", content);
                        tempArtikel.put("status", status);

                        // adding contact to contact list
                        lists.add(tempArtikel);
                    }
                } catch (final JSONException e) {
                    Log.e(TAG, "Json parsing error: " + e.getMessage());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(),
                                    "Json parsing error: " + e.getMessage(),
                                    Toast.LENGTH_LONG).show();
                        }
                    });

                }

            } else {
                Log.e(TAG, "Couldn't get json from server.");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(),
                                "Couldn't get json from server. Check LogCat for possible errors!",
                                Toast.LENGTH_LONG).show();
                    }
                });
            }

            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            ListAdapter adapter = new SimpleAdapter(ArtikelActivity.this, lists,
                    R.layout.list_item, new String[]{ "judul"},
                    new int[]{R.id.judul});
            lv.setAdapter(adapter);
        }
    }

}
