package com.hafidrf.uas_mobile_e_;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class ProsesRegister extends AsyncTask<String, Void, String> {
    private Context context;

    public ProsesRegister (Context context){
        this.context=context;
    }

    @Override
    protected String doInBackground(String... strings) {
        String email = strings[0];
        String nama = strings[1];
        String alamat = strings[2];
        String notelp = strings[3];
        String jeniskelamin = strings[4];
        String pekerjaan = strings[5];
        String password = strings[6];

        String link;
        String data;
        BufferedReader bufferedReader;
        String result;

        try{
            data="?email="+ URLEncoder.encode(email, "UTF-8");
            data += "&nama=" + URLEncoder.encode(nama, "UTF-8");
            data += "&alamat=" + URLEncoder.encode(alamat, "UTF-8");
            data += "&notelp=" + URLEncoder.encode(notelp, "UTF-8");
            data += "&jeniskelamin=" + URLEncoder.encode(jeniskelamin, "UTF-8");
            data += "&pekerjaan=" + URLEncoder.encode(pekerjaan, "UTF-8");
            data += "&password=" + URLEncoder.encode(password, "UTF-8");

            link="http://hafidrf.com/uas/register.php"+data;
            URL url=new URL(link);
            HttpURLConnection con=(HttpURLConnection) url.openConnection();

            bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
            result=bufferedReader.readLine();
            return result;

        } catch (Exception e) {
            return  new String("Exception : "+e.getMessage());
        }
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected void onPostExecute(String s) {
        String jsonStr = s;
        if(jsonStr != null){
            try{
                JSONObject jsonObj=new JSONObject(jsonStr);
                String query_result=jsonObj.getString("result");
                if(query_result.equals("sukses")){
                    Toast.makeText(context, "Berhasil mendaftar!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(context, LoginActivity.class);
                    context.startActivity(intent);
                } else {
                    Toast.makeText(context, "Terjadi kesalahan..", Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e){
                e.printStackTrace();
                Toast.makeText(context, "Ada Kesalahan parsing JSON data.", Toast.LENGTH_SHORT).show();
            }
        }else {
            Toast.makeText(context, "Tidak Dapat Get JSON data.", Toast.LENGTH_SHORT).show();
        }
    }
}
