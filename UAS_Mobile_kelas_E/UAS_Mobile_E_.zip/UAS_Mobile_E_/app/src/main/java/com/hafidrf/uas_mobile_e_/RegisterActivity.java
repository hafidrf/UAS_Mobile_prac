package com.hafidrf.uas_mobile_e_;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {

    EditText email, nama, alamat, telp, pekerjaan, password,konfirmasi_password;
    Spinner txt_jeniskelamin;
    Button btnDaftar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        email = (EditText) findViewById(R.id.email);
        nama = (EditText) findViewById(R.id.nama);
        alamat = (EditText) findViewById(R.id.alamat);
        telp = (EditText) findViewById(R.id.telp);
        pekerjaan = (EditText) findViewById(R.id.pekerjaan);
        password = (EditText) findViewById(R.id.password);
        konfirmasi_password = (EditText) findViewById(R.id.konfirmasi_password);
        txt_jeniskelamin = (Spinner) findViewById(R.id.txt_jeniskelamin);
        btnDaftar = (Button) findViewById(R.id.btn_daftar);
    }

    public void daftar(View v) {
        String valEmail = email.getText().toString();
        String valNama = nama.getText().toString();
        String valAlamat = alamat.getText().toString();
        String valTelp = telp.getText().toString();
        String valPekerjaan = pekerjaan.getText().toString();
        String valPassword = password.getText().toString();
        String valKonfirmasiPassword = konfirmasi_password.getText().toString();

        String valjeniskelamin = String.valueOf(txt_jeniskelamin.getSelectedItem().toString());

        if (!valEmail.isEmpty() && !valNama.isEmpty() && !valAlamat.isEmpty() && !valTelp.isEmpty() && !valPassword.isEmpty() && !valPekerjaan.isEmpty() && !valKonfirmasiPassword.isEmpty()) {
            if (Patterns.EMAIL_ADDRESS.matcher(valEmail).matches()) {
                if (valPassword.equals(valKonfirmasiPassword)) {
                    new ProsesRegister(this).execute(valEmail, valNama, valAlamat, valTelp, valjeniskelamin, valPekerjaan, valPassword);
                } else {
                    Toast.makeText(this, "Kata sandi tidak cocok.", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Format email tidak valid.", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Semua kolom harus diisi.", Toast.LENGTH_SHORT).show();
        }
    }

    public void login(View v) {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }
}
