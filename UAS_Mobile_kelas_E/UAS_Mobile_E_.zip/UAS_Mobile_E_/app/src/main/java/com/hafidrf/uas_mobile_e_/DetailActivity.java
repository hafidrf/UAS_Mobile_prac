package com.hafidrf.uas_mobile_e_;

import android.content.Context;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class DetailActivity extends AppCompatActivity {

    TextView judul, kategori, content;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        judul = (TextView) findViewById(R.id.detailJudul);
        kategori = (TextView) findViewById(R.id.detailKategori);
        content = (TextView) findViewById(R.id.detailContent);

//        String valJudul = getIntent().getStringExtra("judul");
//        String valKategori = getIntent().getStringExtra("kategori");
//        String valContent = getIntent().getStringExtra("content");
//
//        judul.setText(valJudul);
//        kategori.setText(valKategori);
//        content.setText(valContent);

        String id = getIntent().getStringExtra("idartikel");

        new DetailService(this).execute(id);
    }

    private class DetailService extends AsyncTask<String, Void, String> {
        private Context context;

        public DetailService(Context context){
            this.context=context;
        }

        @Override
        protected String doInBackground(String... strings) {
            String id = strings[0];

            String link;
            String data;
            BufferedReader bufferedReader;
            String result;

            try{
                data="?id="+ URLEncoder.encode(id, "UTF-8");

                link="http://hafidrf.com/uas/artikel.php"+data;
                URL url=new URL(link);
                HttpURLConnection con=(HttpURLConnection) url.openConnection();

                bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                result=bufferedReader.readLine();
                return result;

            } catch (Exception e) {
                return  new String("Exception : "+e.getMessage());
            }
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String s) {
            String jsonStr = s;
            if(jsonStr != null){
                try{
                    JSONObject jsonObj = new JSONObject(jsonStr);
                    String valJudul = jsonObj.getString("judul");
                    String valContent = jsonObj.getString("content");
                    String valKategori = jsonObj.getString("idkategori");

                    if (valKategori.equalsIgnoreCase("1")){
                        valKategori = "berita utama";
                    } else {
                        valKategori = "artikel";
                    }

                    judul.setText(valJudul);
                    kategori.setText(valKategori);
                    content.setText(valContent);
                } catch (JSONException e){
                    e.printStackTrace();
                    Toast.makeText(context, "Ada Kesalahan parsing JSON data.", Toast.LENGTH_SHORT).show();
                }
            }else {
                Toast.makeText(context, "Tidak Dapat Get JSON data.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}