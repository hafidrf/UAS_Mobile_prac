package com.hafidrf.uas_mobile_e_;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class ProsesLogin extends AsyncTask<String, Void, String> {
    private Context context;

    public ProsesLogin(Context context){
        this.context=context;
    }

    @Override
    protected String doInBackground(String... strings) {
        String email = strings[0];
        String password = strings[1];

        String link;
        String data;
        BufferedReader bufferedReader;
        String result;

        try{
            data="?email="+ URLEncoder.encode(email, "UTF-8");
            data += "&password=" + URLEncoder.encode(password, "UTF-8");

            link="http://hafidrf.com/uas/login.php"+data;
            URL url=new URL(link);
            HttpURLConnection con=(HttpURLConnection) url.openConnection();

            bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
            result=bufferedReader.readLine();
            return result;

        } catch (Exception e) {
            return  new String("Exception : "+e.getMessage());
        }
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected void onPostExecute(String s) {
        String jsonStr = s;
        if(jsonStr != null){
            try{
                JSONObject jsonObj=new JSONObject(jsonStr);
                String query_result=jsonObj.getString("result");

                if(query_result.equals("true")){
                    Toast.makeText(context, "Berhasil login!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(context, ArtikelActivity.class);
                    context.startActivity(intent);
                } else {
                    Toast.makeText(context, "Email atau password tidak cocok!", Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e){
                e.printStackTrace();
                Toast.makeText(context, "Ada Kesalahan parsing JSON data.", Toast.LENGTH_SHORT).show();
            }
        }else {
            Toast.makeText(context, "Tidak Dapat Get JSON data.", Toast.LENGTH_SHORT).show();
        }
    }
}
