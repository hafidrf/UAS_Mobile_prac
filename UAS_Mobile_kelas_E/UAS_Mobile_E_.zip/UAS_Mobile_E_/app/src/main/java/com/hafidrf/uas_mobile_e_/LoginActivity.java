package com.hafidrf.uas_mobile_e_;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    EditText txtEmail, txtPassword;
    Button btnLogin,btnRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        txtEmail = (EditText) findViewById(R.id.txtEmail);
        txtPassword = (EditText) findViewById(R.id.txtPassword);
        btnLogin = (Button) findViewById(R.id.btnLogin);
        btnRegister = (Button) findViewById(R.id.btn_daftar);
    }

    public void login(View v) {
        String email = txtEmail.getText().toString();
        String password = txtPassword.getText().toString();

        if (Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            new ProsesLogin(this).execute(email, password);
        } else {
            Toast.makeText(this, "Format email tidak valid.", Toast.LENGTH_SHORT).show();
        }
    }

    public void daftar(View v) {
        Intent intent = new Intent(this, RegisterActivity.class);
        startActivity(intent);
    }
}
